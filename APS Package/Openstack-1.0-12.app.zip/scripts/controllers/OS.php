<?php

require_once 'OpenStackV2Controller.php';
require_once 'OpenStackV3Controller.php';

class OS {

    private $url = null;
    private $user = null;
    private $password = null;
    private $controller = null;
    private $token = null;

    function __construct($url, $user, $password) {
        $this->url = $url;
        $this->user = $user;
        $this->password = $password;

        $this->controller = new OpenStackV2Controller($this->url);
    }

    function getToken() {
        $data = $this->controller->authenticateAndGenerateToken($this->user, $this->password);
        return $data;
    }

    function getIPPools() {
        $data = $this->controller->listIPPools($this->token);
        return $data;
    }

    function getProjects() {
        
    }
    
    function getTenants(){
        
    }

}
