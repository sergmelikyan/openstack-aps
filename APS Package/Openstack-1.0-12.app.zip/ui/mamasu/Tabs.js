require([
     "dojo/_base/declare", "dojo/parser", "dojo/ready",
     "dijit/_WidgetBase", "dijit/_TemplatedMixin"
 ], function(declare, parser, ready, _WidgetBase, _TemplatedMixin){

     declare("Tabs", [_WidgetBase, _TemplatedMixin], {
         templateString: "\
            <div class='tabs'>\
                <div class='tabs-area'>\
                    <ul>"
                                                        ["<li>", {id: "first-tab", class: "active"}, [
                                                                ["<a>", {style: "cursor:default;", href: "javascript:void(0);"}, [
                                                                        ["<span>", {innerHTML: _("Settings")}]
                                                                    ]]
                                                            ]],
                                                        ["<li>", {}, [
                                                                ["<a>", {href: "javascript:void(0);"}, [
                                                                        ["<span>", {innerHTML: _("Ippools")}]
                                                                    ]]
                                                            ]],
                                                        ["<li>", {id: "last-tab"}, [
                                                                ["<a>", {href: "javascript:void(0);"}, [
                                                                        ["<span>", {innerHTML: _("ISO")}]
                                                                    ]]
                                                            ]]
                                                    ]]
                                            ]]
                                    ]],

         increment: function(){
             this.counter.innerHTML = ++this._i;
         }
     });

     ready(function(){
         // Call the parser manually so it runs after our widget is defined, and page has finished loading
         parser.parse();
     });
 });