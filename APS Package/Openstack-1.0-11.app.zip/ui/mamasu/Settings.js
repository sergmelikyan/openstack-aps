define([], function () {
    return {
        environment: "DEV", //DEV,PROD,TEST
        mainPageId: 'main_page',
        maximizer: false,
        maximizeOnStart: false,
        htmlMessages: true
    };
});