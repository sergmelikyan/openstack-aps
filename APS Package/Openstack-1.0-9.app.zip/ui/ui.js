define([
    "dijit/registry",
    "aps/Message",
    "system.js"
], function (registry,Message,system) {
    var UI = {
        _showMessage: function (message, typeMsg) {
            UI.log("MESSAGE", message);
            var containerId = system.mainPageId;
            var page = registry.byId(containerId);
            if (page === undefined) {
                containerId = "page";
                page = registry.byId(containerId);
            }
            var messages = page.get("messageList");
            aps.apsc.cancelProcessing();
            messages.removeAll();
            messages.addChild(new Message({
                description: message,
                type: typeMsg
            }));
        },
        showSuccess: function (msg) {
            UI._showMessage(msg, "info");
        },
        showInfo: function (msg) {
            UI._showMessage(msg, "");
        },
        showWarning: function (msg) {
            UI._showMessage(msg, "warning");
        },
        showError: function (error) {
            UI._showMessage(UI.getErrorMsg(error), "error");
        },
        getErrorMsg: function (error) {
            var errMsg = "";
            try {
                var errData = JSON.parse(error.response.text);
                errMsg = errData.message;
            } catch (e) {
                errMsg = error;
            }
            return errMsg;
        },
        log: function () {
            if (system.environment !== "PROD") {
                console.log("[LOG]", arguments);
            }
        },
        plainLog: function (log) {
            if (system.environment !== "PROD") {
                console.log(log);
            }
        },
        clearConsole: function () {
            if (system.environment !== "PROD") {
                console.clear();
            }
        }
    };
    return UI;
});