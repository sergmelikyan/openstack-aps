//http://patorjk.com/software/taag/#p=display&f=Big&t=Mamasu%20Lib.
var helloMessage = "      _                                         ___  __ \n\
     | |                                       / _ \\/_ |\n\
   __| |____ _ __ ___   __ _ _ __ ___   __   _| | | || |\n\
  / _` |____| '_ ` _ \\ / _` | '_ ` _ \\  \\ \\ / / | | || |\n\
 | (_| |    | | | | | | (_| | | | | | |  \\ V /\| |_| || |\n\
  \\__,_|    |_| |_| |_|\\__,_|_| |_| |_|   \\_/  \\___(_)_| powered by Jepi & Carlos";

var System = {
    environment: "DEV", //DEV,PROD,TEST
    _showMessage: function(message, typeMsg, target) {
        System.log("MESSAGE", message);
        var containerId = target || "main_page";
        var page = registry.byId(containerId);
        if (page === undefined) {
            containerId = "page";
            page = registry.byId(containerId);
        }
        var messages = page.get("messageList");
        aps.apsc.cancelProcessing();
        messages.removeAll();
        messages.addChild(new Message({
            description: message,
            type: typeMsg
        }));
    },
    showSuccess: function(msg, target) {
        System._showMessage(msg, "info", target);
    },
    showInfo: function(msg, target) {
        System._showMessage(msg, "", target);
    },
    showWarning: function(msg, target) {
        System._showMessage(msg, "warning", target);
    },
    showError: function(error, target) {
        System._showMessage(System.getErrorMsg(error), "error", target);
    },
    getErrorMsg: function(error) {
        var errMsg = error;
        try {
            var errData = JSON.parse(error.response.text);
            errMsg = errData.message;
        } catch (e) {
        }
        return errMsg;
    },
    log: function() {
        if (System.environment !== "PROD") {
            console.log("[LOG]", arguments);
        }
    },
    plainLog: function(log) {
        if (System.environment !== "PROD") {
            console.log(log);
        }
    },
    clearConsole: function() {
        if (System.environment !== "PROD") {
            console.clear();
        }
    }
};

var UI = {
    node: function(id) {
        var node = document.getElementById(id);
        return node;
    },
    hide: function(id) {
        $(this.node(id)).hide();
//        this.node(id).set("visible", false);
    },
    show: function(id) {
//        this.node(id).set("visible", true);
        $(this.node(id)).show();
    }
};

var Subscription = {
    isUnlimited: function(apsTypeId) {

    }
};

function removeIfExists(id) {
    if (registry.byId(id) !== undefined) {
        if (registry.byId(id).removeAll !== undefined) {
            registry.byId(id).removeAll();
        }
        registry.byId(id).destroy();
    }
}

function emptyContainer(id) {
    var container = registry.byId(id);
    if (container !== undefined) {
        if (container.removeAll !== undefined) {
            container.removeAll();
        }
        var domNodeLength = container.domNode.childNodes.length;
        if (domNodeLength > 0) {
            var child = undefined;
            for (var i = 0; i < domNodeLength; i++) {
                child = container.domNode.childNodes[i];
                if (child !== undefined && child.id !== undefined) {
                    removeIfExists(child.id);
                }
            }
        }

    }
}

function replaceAll(find, replace, str) {
    return str.replace(new RegExp(find, 'g'), replace);
}

var ECRUD = {
    list: function(type) {
        var store = new ResourceStore({
            target: "/aps/2/resources/",
            apsType: type
        });
        var def = new Deferred();
        store.query().then(def.resolve).otherwise(def.reject);
        return def;
    },
    create: function(item, target) {
        target = target || "";
        var store = new ResourceStore({
            target: "/aps/2/resources/" + target
        });
        var def = new Deferred();
        store.add(item).then(def.resolve).otherwise(def.reject);
        return def;
    },
    read: function(target) {
        var store = new ResourceStore({
            target: "/aps/2/resources/"
        });
        var def = new Deferred();
        store.get(target).then(def.resolve).otherwise(def.reject);
        return def;
    },
    types: function() {
        var store = new ResourceStore({
            target: "/aps/2/types/"
        });
        var def = new Deferred();
        store.query().then(def.resolve).otherwise(def.reject);
        return def;
    },
    update: function(item) {
        var store = new ResourceStore({
            target: "/aps/2/resources/"
        });
        var def = new Deferred();
        store.put(item).then(def.resolve).otherwise(def.reject);
        return def;
    },
    put: function(target, data) {
        return xhr.put("/aps/2/resources/" + target, {data: data});
//        xhr("/aps/2/resources/" + that.apsId, {method: "DELETE", handleAs: "text"}), function(data) {
    },
    delete: function(target) {
        var def = new Deferred();
        xhr.del("/aps/2/resources/" + target).then(def.resolve).otherwise(def.reject);
        return def;
    },
    successDelete: function(target) {
        var def = new Deferred();
        xhr.del("/aps/2/resources/" + target).then(function() {
            def.resolve([_("Resource __ID__", {ID: target}) + ": " + _("Removed!")]);
        }).otherwise(function(err) {
            def.resolve(_("Resource __ID__", {ID: target}) + ": " + System.getErrorMsg(err));
        });
        return def;
    },
    deleteCollection: function(globalResources) {
        var promises = [];
        for (var i = 0; i < globalResources.length; i++) {
            promises.push(this.successDelete(globalResources[i].aps.id));
        }
        var def = new Deferred();
        all(promises).then(function(data) {
            var message = "";
            for (var i = 0; i < data.length; i++) {
                message += data[i] + "<br />";
            }
            def.resolve(message);
        }).otherwise(def.reject);
        return def;
    }
};

function requireMamasu(libraries, iniFunction) {
    var defaultLibraries = [
        "aps/ResourceStore",
        "dojo/when",
        "dijit/registry",
        "aps/parser",
        "dojo/has",
        "dojo/query",
        "dojo/dom",
        "aps/Memory",
        "aps/Toolbar",
        "aps/ToolbarButton",
        "aps/Button",
        "dojox/mvc/getStateful",
        "dojox/mvc/getPlainValue",
        "aps/Message",
        "dojo/Deferred",
        "dojo/_base/lang",
        "dojox/mvc/at",
        "dojo/promise/all",
        "aps/load",
        "aps/xhr",
        "aps/app"];
    var argumentStrings = [];
    System.clearConsole();
    System.plainLog(helloMessage);
    for (var i = 0; i < defaultLibraries.length; i++) {
        libraries.push(defaultLibraries[i]);
    }
    for (i = 0; i < libraries.length; i++) {
        var newArgStr = libraries[i].split("/");
        newArgStr = newArgStr[newArgStr.length - 1];
        newArgStr = newArgStr.split(".");
        newArgStr = newArgStr[0];
        argumentStrings.push(newArgStr);
    }
    libraries.push("aps/ready!");

    require(libraries, function() {
        //Add libraries to global environment
        for (var i = 0; i < arguments.length; i++) {
            window[argumentStrings[i]] = arguments[i];
        }

        load(["aps/PageContainer", {id: "page"}]).then(function() {
            //Call required function
            iniFunction();
            //Define an error handler to get all errors uncatched
            window.onerror = function(err) {
                System.showError(err);
                query('.apsButton').forEach(function(node) {
                    registry.byNode(node).cancel();
                });
                //To allow APS to continue running as well, it's need to cancel throw stack
                return false;
            };
        }).otherwise(function(err) {
            System.log("ERROR BEFORE TO START: ", err);
        });
    });
}

function clone(obj) {
// Handle the 3 simple types, and null or undefined
    if (null === obj || "object" !== typeof obj)
        return obj;
    // Handle Date
    if (obj instanceof Date) {
        var copy = new Date();
        copy.setTime(obj.getTime());
        return copy;
    }

// Handle Array
    if (obj instanceof Array) {
        var copy = [];
        for (var i = 0, len = obj.length; i < len; i++) {
            copy[i] = clone(obj[i]);
        }
        return copy;
    }

// Handle Object
    if (obj instanceof Object) {
        var copy = {};
        for (var attr in obj) {
            if (obj.hasOwnProperty(attr))
                copy[attr] = clone(obj[attr]);
        }
        return copy;
    }

    throw new Error("Unable to copy obj! Its type isn't supported.");
}