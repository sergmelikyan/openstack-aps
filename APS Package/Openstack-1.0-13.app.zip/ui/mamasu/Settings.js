define([], function () {
    return {
        environment: "DEV", //DEV,PROD,TEST
        mainPageId: 'main_page',
        htmlMessages: true
    };
});